#version 330 core
in vec3 Normal;
in vec2 UV;
in vec4 LightPos;
uniform vec3 color,lightDir;
uniform sampler2D diffuseTex,shadowMap;
uniform int useTexture;
out vec4 FragColor;
float shadowAmount(vec4 lp,vec3 n){
 vec3 proj=lp.xyz/lp.w;
 proj=proj*0.5+0.5;
 if(proj.z>1.0 || proj.z<0.0) return 0.0;
 float closest=texture(shadowMap,proj.xy).r;
 float bias=max(0.003*(1.0-dot(normalize(n),normalize(-lightDir))),0.0008);
 return proj.z-bias>closest ? 0.45 : 0.0;
}
void main(){
 vec3 n=normalize(Normal);
 float diffuse=max(dot(n,normalize(-lightDir)),0.0);
 float shadow=shadowAmount(LightPos,n);
 vec3 base=useTexture==1 ? texture(diffuseTex,UV).rgb*color : color;
 vec3 lit=base*(0.48+(1.0-shadow)*0.52*diffuse);
 FragColor=vec4(lit,1.0);
}
