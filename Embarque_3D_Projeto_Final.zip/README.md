# Embarque 3D — OpenGL

Simulação de ônibus parando, personagem fazendo sinal com o braço e embarcando.

## Executar

Requer Python 3.12 e suporte a OpenGL 3.3.

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python main.py
```

Controles: Espaço pausa; R reinicia; +/- velocidade; setas ou WASD câmera; Q/E zoom; Esc sai.
